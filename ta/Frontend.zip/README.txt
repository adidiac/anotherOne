Necesar: node js 
Instructiuni pornire
1. Din terminal in folderul curent executati: npm install
2. Din terminal in folderul curent executati: npm start
3. Din browser acesati adresa: http://localhost:3000/

In prima faza veti vedea pagina cu servicii de IA pentru un user guest.

Ca sa vedeti si pentru un user logat mergeti in ./src/Redux/userRedux.js    
Acolo din cei trei tipi de user vor fi disponibili:
- guest
- user
- admin
Decomentati este user:null adica guest pentru accesera paginilor suplimentare de admin si user comentati user:null si decomentati pe cel corespunzator
si dati refresh la pagina

Hint: folositi butoanele din navbar