import {Modal, Button,Tab,Container,Row,Col} from 'react-bootstrap';
import {useState,useEffect} from 'react';
import { useDispatch,useSelector } from 'react-redux';
export default function ModalUser({show,setShow})
{
    const user=useSelector(state=>state.userRedux.user);
    const dispatch=useDispatch();
    return (<Modal show={show} onHide={()=>setShow(false)}>
    <Modal.Header closeButton>
        <Row>
            <Col>
        <Modal.Title>{user?user.name:<></>}</Modal.Title>
            </Col>
            <Col>
        <Button onClick={()=>{dispatch({type:"Logout"})}}>Logout</Button>
        </Col>
        </Row>
    </Modal.Header>
    <Modal.Body>
        <Container style={{overflowY:"scroll",maxHeight:300}}>
            <Row>
                <h4>Subscriptions:</h4>
                {
                    //print tiles of user
                    user?user.tiles.map((el)=>{
                        return <Tab.Pane eventKey={el}>
                            {el}
                        </Tab.Pane>
                    }):<></>
                }
            </Row>
            <br></br>
            <h4>History:</h4>
            {user?user.history.map((el)=>{
                return <>
                <Row>
                    <Col>
                        <p>Text :{el.text}</p>
                    </Col>
                    <Col>
                        <p>Sentiment :{el.sentiment}</p>
                    </Col>
                    <Col>
                        <p>Language: {el.language}</p>
                    </Col>
                    <Col>
                        <p>Entity: {el.entity}</p>
                    </Col>
                    <Col>
                        <p>Opinion: {el.opinion}</p>
                    </Col>
                </Row>
                <hr></hr>
                </>
            }):<></>}
        </Container>
    </Modal.Body>
    <Modal.Footer>
        <Button variant="secondary" onClick={()=>setShow(false)}>
            Close
        </Button>
    </Modal.Footer>
    </Modal>
    );
}