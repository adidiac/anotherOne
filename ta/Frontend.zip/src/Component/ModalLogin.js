import {Modal, Button,Tab,Container,Row,Col,Form} from 'react-bootstrap';
import { useState } from "react";
export default function ModalLogin({show,setShow})
{
    const [body,setBody]=useState(0);
    const [services,SetServices]=useState([]);
    const [totalPrice,setTotalPrice]=useState(0);

    const login=(email,password)=>{
        //TODO: send login
    }
    const register=(name,email,password)=>{
        //TODO: send register
    }
        



    const addToTotal=(price)=>{
        setTotalPrice(totalPrice+price);
    }
    const removeFromTotal=(price)=>{
        setTotalPrice(totalPrice-price);
    }
    const checkIfExist=(service)=>{
        for(let i=0;i<services.length;i++)
        {
            if(services[i]==service)
            {
                console.log("exist");
                return true;
            }
        }
        return false;
    }
    const addService=(service)=>{
        SetServices([...services,service]);
    }
    const deleteService=(service)=>{
        SetServices(services.filter(s=>s!==service));
    }

    const renderBody=()=>{
        if(!body)
        {
            return <>
                <Form>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control type="email" placeholder="Enter email" />
                    <Form.Text className="text-muted">
                    We'll never share your email with anyone else.
                    </Form.Text>
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="Password" />
                </Form.Group>
                <Button variant="primary" type="submit" onClick={()=>{setShow(false);setBody(0)}}>
                    Login
                </Button>`
                
                <Button variant="primary" onClick={()=>{setBody(1)}} >
                    Register
                </Button>`
                </Form>
            </>
        }
        else
        {
            return <>
            <Form>
                <Form.Group className="mb-3" controlId="formBasicPassword">
                    <Form.Label>Your name</Form.Label>
                    <Form.Control type="text" placeholder="Your name" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control type="email" placeholder="Enter email" />
                    <Form.Text className="text-muted">
                    We'll never share your email with anyone else.
                    </Form.Text>
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="Password" />
                </Form.Group>
                <hr></hr>
                <Row>
                    <Col>
                        <h7>Language detection</h7>
                    </Col>
                    <Col>
                        <h7>Price 20$</h7>
                    </Col>
                    <Col>
                    {checkIfExist("Language detection")?
                        <Button variant="danger" onClick={()=>{deleteService("Language detection");removeFromTotal(20)}}>
                            Remove
                        </Button>:
                        <Button variant="primary" onClick={()=>{addService("Language detection");addToTotal(20)}}>
                            Add
                        </Button>
            }
                    </Col>
                </Row>
                <hr></hr>
                <Row>
                    <Col>
                        <h7>Entity detection</h7>
                    </Col>
                    <Col>
                        <h7>Price 20$</h7>
                    </Col>
                    <Col>
                    {checkIfExist("Entity detection")?
                        <Button variant="danger" onClick={()=>{deleteService("Entity detection");removeFromTotal(20)}}>
                            Remove
                        </Button>:
                        <Button variant="primary" onClick={()=>{addService("Entity detection");addToTotal(20)}}>
                            Add
                        </Button>
                    }       
                    </Col>
                </Row>
                <hr></hr>
                <Row>
                    <Col>
                        <h7>Opinion mining</h7>
                    </Col>
                    <Col>
                        <h7>Price 20$</h7>
                    </Col>
                    <Col>
                    {checkIfExist("Opinion mining")?
                        <Button variant="danger" onClick={()=>{deleteService("Opinion mining");removeFromTotal(20)}}>
                            Remove
                        </Button>:
                        <Button variant="primary" onClick={()=>{addService("Opinion mining");addToTotal(20)}}>
                            Add
                        </Button>
                     }
                    </Col>
                </Row>
                <hr></hr>
                <Row>
                    <Col>
                        <h7>Total price : {totalPrice}</h7>
                    </Col>
                </Row>
                <hr></hr>
                <Button variant="primary" type='submit' onClick={()=>{setShow(false);setBody(0)}} >
                    Register
                </Button>`
                </Form>
            
            </>
        }
    
    
    }
    return (<Modal show={show} onHide={()=>{setShow(false);setBody(0)}}>
    <Modal.Header closeButton>
        <Modal.Title>Login</Modal.Title>
    </Modal.Header>
    <Modal.Body>
        <Container>
        {renderBody()}
        </Container>
    </Modal.Body>
    <Modal.Footer>
        <Button variant="secondary" onClick={()=>{setShow(false);setBody(0)}}>
            Close
        </Button>
    </Modal.Footer>
    </Modal>
    );
}